<?php
// Heading
$_['heading_title']       = 'Boleto Bradesco';
$_['heading_description'] = 'Configuração para pagamentos com Boleto Bancario.';
// Text
$_['text_boletobradesco'] = '<img src="view/image/payment/spsbradesco.png" alt="Loja5" title="Loja5" style="border: 1px solid #EEEEEE;" />';
?>