
This is my second simple vqmod. Hope it will be usefull. 
Sorry for my bad english.

How to use this mod :

Just upload to your vqmod xml folder. Thanks

Regards,

immux
imam.mukhlisin@immux.com
